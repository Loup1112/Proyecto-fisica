package fisica;


import fisica.Vista.VentanaInicio;

/**
 * <p>
 * Es la Clase principal que ejecuta el frame inicial
 * </p>
 * 
 * @author Miguel Guzman 20182020127
 * @author Jeasson Suarez 20182020107
 * @author Catalina Preciado 20182020122
 * @since 10/07/2019
 * @version 1.0
 */

public class EjecutarJuego {
	public static void main(String[] args) {
		
			VentanaInicio inicio = new VentanaInicio();
			inicio.setVisible(true);
		
	}

}
